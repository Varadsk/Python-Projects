import random
def price():
    price=int(input("Enter Price:"))
    qty=int(input("Enter Qantity:"))
    chrgs=int(input("Enter Charges:"))
    b_id=random.randint(1,101)
    gst=(price*12)/100
    tc= price * qty + chrgs
    
    print("\n------------Bill recipt-----------")
    print("Bill Id:",b_id)
    print("Quantity:",qty)
    print("Price:",price)
    print("Charges Apply:",chrgs)
    print("GST included:",gst)
    print("\n------ Total Amount:",tc,"--------")
    print("(Charges may apply as per the custom duties and GST's)")
    print("Amount without gst:",tc-gst)
    

    
def main():
    print("\n########Book purchase system########")
    print("Select Department:")
    print("1.Mechanical\n2.Automobile\n3.Computer\n4.Electronics and Telecommunication")
    mech=['SOM','TOM','APM']
    auto=['SOM','TOM','APM']
    comp=['PIC','WPD','ACN']
    etc=['BEC','EEC','DTE']
    ch=int(input(""))
    if(ch==1):
        print(mech)
        print("select the subject from the list")
        #print("1.SOM \n2.TOM\n3.APM")
        book_mech=int(input(""))
        print("book department:Mechanical")
        price()
        cont=int(input("\n\nWould you like to countinue \n1.Yes 2.No\n"))
        if(cont==1):
            main()
        else:
            print("You Exited successfully!!!")
            exit()


    if(ch==2):
        print(auto)
        print("select the subject from the list")
       # print("1.SOM \n2.TOM\n3.APM")
        book_auto=int(input(""))
        print("book department:Automobile")
        price()
        cont_1=int(input("\n\nWould you like to countinue \n1.Yes 2.No\n"))
        if(cont_1==1):
            main()
        else:
            print("You Exited successfully!!!")
            exit()
    
    if(ch==3):
        print(comp)
        print("select the subject from the list")
       # print("1.PIC \n2.WPD\n3.ACN")
        book_comp=int(input(""))
        print("book department:Computer")
        price()
        cont_2=int(input("\n\nWould you like to countinue \n1.Yes 2.No\n"))
        if(cont_2==1):
            
            main()
        else:
            print("You Exited successfully!!!")
            exit()
   
    if(ch==4):
        print(etc)
        print("select the subject from the list")
       # print("1.BEC \n2.EEC\n3.DTE")
        book_etc=int(input(""))
        print("book department:Electronics and Telecommunication")
        price()
        cont_2=int(input("\n\nWould you like to countinue \n1.Yes 2.No\n"))
        if(cont_2==1):
            main()
        else:
            print("You Exited successfully!!!")
            exit()    
    if(ch<1 or ch>4):
        print("Wrong Selection Try Once again!")
main()
